# Dropdown Menu Widget Changelog

This page lists all the major changes to the **Dropdown Menu Widget** for WordPress.
Please visit [Dropdown Menu Widget Homepage](http://metinsaylan.com/projects/wordpress/dropdown-menu-widget/) for more information.

### 1.9.6

* Fixed rename homepage problem
* Removed table wrapper around the menu, added a div instead
* Removed all unnecessary files (well nearly all)
* Removed tabs and simplified settings page for responsiveness
* Updated documentation links and descriptions
* Removed crappy widget footer links

### 1.9.3

* Updated WordPress version for compatibility.

### 1.9.2

* Added: Settings link on plugins page.
* Added: Plugin activation redirect to Settings page.
* Added: Filter wp_nav_menu arguments to create a dropdown menu. Theme can be changed via dropdown menu settings page.
* Added: Demo menu on settings page.
* Removed: Unnecessary scripts from scripts folder.
* Removed: Twitter box on settings page.
* Some minor fixes and tidy up on options page.

### 1.9.1  

* Added: More detailed faq and plugin banner.

### 1.9  

* Changed: Minimized included CSS file.
* Added: Support for changing arrow colors.
* Added: Help links next to options settings fields.
* Added: New Theme Rounded Corners.
* Added: New Theme Rounded Corners Light.
* Added: New Theme Pills.

### 1.8.1  

* Fixed: HoverIntent hotfix for older version users. (Thanks to Karsten)
* Fixed: Various theme problems with vertical menus.

### 1.8  

* Fixed: HoverIntent hotfix for Wordpress 3.3

### 1.7.2  

* Fixed: Widget hotfix.

### 1.7.1  

* Fixed: Template tag hotfix. Fixes displaying vertical instead of horizontal.

### 1.7  

* Added: brand new options page.
* Added: Web2.0 Theme.
* Added: width option to widgets.
* Fixed: Right aligned menu dropdown errors.
* Added: Effect delay option (hoverIntent).
* Added: Plugin both search theme & template folders for dropdown.css
* Added: Adminbar button to easily change current options.

### 1.6.4  

* Fixed effect selector error.
* Added width option for vertical menus.

### 1.6.3  

* Fixed: Supplied arguments for the menu overwritten in the menu function.
* Added: Now you can easily add menus using menu names & ids and even locations.

### 1.6.2  

* Fixed: Stylesheet causing widgets go behind widget containers. (Thanks to Antonio Capone for reporting the issue)

### 1.6.1  

* Fix: Colorscheme background error.
* Fix: jQuery not included when effects are enabled.
* Added: Disabling options that are not used.
* Added: Custom Theme URL option.

### 1.6  

* Added option to show title on widget.
* Added capability to find dropdown.css on your theme folder.
* Added jQuery dropdown effects.
* Added remove title attributes option.
* Added remove links from top level option.
* Many more to come..

### 1.5.8  

* Added dropdown_menu_defaults filter for changing default options like order, depth etc.

### 1.5.7  

* Fixed various css issues.
* Removed backgrounds for IE on certain themes.
* Hopefully works with all browsers with javascript enabled (Tested with Chrome, Firefox, Safari, Opera and IE6).
* Please submit any bugs you see on [dropdown menu plugin page](http://shailan.com/wordpress/plugins/dropdown-menu/)

### 1.5.6beta  

* Added hooks for inserting your own menu & other navigational elements.
* Fixed z-index errors.
* Fixed background problem with custom theme selection.
* Added "include archives" option to Dropdown-Multi widget.

### 1.5.6alpha1  

* Fixed sub menu display errors.
* Added alignment option to template tag support.

### 1.5.6alpha  

* Fixed options page saving error.
* Added a brand new color selection interface for custom "Color Scheme" (beta).
* Now you can easily select your own colors & plus overlays!

### 1.5.5  

* New theme! Hulu style theme.
* Added new action hooks to insert your items to the dropdown menu.

### 1.5.4  

* Added first-child & last-child selector for styling to dropdown menu. (available when jquery is active only)
* Fixed IE display errors for shiny black theme.
* Fixed not saving issues with the plugin options.

### 1.5.3  

* Made Custom CSS area available even when a theme is selected. You can now use this area for your theme customizations.
* Fixed `Call undefined function wp_nav_menu on 365` error.
* Fixed font-size problems with `Shiny Black` theme.
* Removed behaviour fix for IE. Now using only jquery as dropdown fix which comes packed with wordpress.

### 1.5.2  

* Fixed tested version number.
* Added screenshot 2.
* Added options page screenshot.
* Now plugin allows you to rename the home link.

### 1.5.1  

* Removed custom walker support for now.
* Removed blue tabs theme since it was using custom walkers.
* Fixed all the styles to work with new css classes.
* Updated Shiny Black theme to work with wide links.
* Complete support for custom css insert.

### 1.5  

* Fixed issues with wordpress 3.0.
* Renamed plugin to dropdown menu.
* Removed inline style option.
* Removed unnecessary screenshots.
* Added support for wordpress 3.0 navigation menus.
* Removed exclude pages plugin.

### 1.4.1  

* A minor fix for `Parse error: parse error, expecting 'T_FUNCTION' in C:\wamp\www\wordpress\wp-content\plugins\dropdown-menu-widget\shailan-multi-dropdown.php on line 194` error.

### 1.4.0  

* Added option for multiline links. If checked a link with more than one word will be wrapped.
* Another fix for IE. Hopefully last.

### 1.3.9  

* Fixed errors for IE jquery support.
* Added belorussian translation provided by [Marcis G.](http://pc.de)
* Added lang folder for translations.

### 1.3.8  

* Added option for displaying title attributes. You may now turn title display on from the Settings page.

### 1.3.7  

* Removed unnecessary extrude line from Dropdown Multi widget.

### 1.3.6  

* Fixed "Dropdown Multi" widget error with categories and links.

### 1.3.5  

* Added "Dropdown Multi" widget that allows you to inlude pages, categories and links in one menu.

### 1.3.4  

* Fixed dropdown errors for IE7. Report any bugs with a screenshot please. Thanks.

### 1.3.3  

* Fixed function name collisions with "Exclude Pages" plugin. The plugin is fully functional now.

### 1.3.2  

* Bundled with "Exclude Pages" plugin by [Simon Wheatley](http://simonwheatley.co.uk/wordpress/). You can now easily exclude pages from the navigation. Just uncheck the the "Include page in menus" checkbox on the page edit screen. See [screenshots](http://wordpress.org/extend/plugins/dropdown-menu-widget/screenshots/) for more information.

### 1.3.1  

* Added "Blue gradient" theme.

### 1.3.0  

* Fixed "Home" link bug for the template tag. Thanks to Jeff.

### 1.2.7    

* Added "include homepage link" for both pages and categories now. You can enable/disable this link from the widget options easily.

### 1.2.6  

* Fixed a minor bug.

### 1.2.5  

* Added translation support.
* Added pot file for translators.

### 1.2.4  

* Fixed category walker for the advanced styling.

### 1.2.3  

* Added Aqua theme.
* Added <span> elements in the menu so more advanced styling can be made.
* Added alignment option. Now you can align your menu wherever you wanted!
* Added Shiny Black theme.

### 1.2.0  

* Removed title attributes for the categories dropdown menu items.

### 1.1.0  

* Added custom walker class to disable title attributes on menu items.
* Renamed class and style files.
* Fixed default theme.

### 1.0.0  

* Added vertical dropdown menu functionality.
* Fixed widget code.
* Changed dropdown widget classname to : shailan-dropdown-menu
* Changed wrapper div classname to : shailan-dropdown-wrapper
* Moved li item paddings to anchor elements.

### 0.4.3  

* New grayscale theme.
* Template tag `shailan_dropdown_menu()` is available now. See usage for more info.
* Template tag options added.

### 0.4.2  

* Fixed XHTML error on link tags.
* Fixed Inline Style error on categories dropdown menu.
* Removed unnecessary files.

### 0.4.1  

* Fixed XHTML issues.
* Added WP Default theme.
* Made some minor fixes to widget options form.

### 0.3  

* Fixed problems about styling. Now you can change dropdown menu style from the options page.

### 0.2  

* First public release.
* Added login and register button options.
